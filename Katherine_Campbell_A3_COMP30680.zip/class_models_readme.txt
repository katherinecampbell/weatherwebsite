Read me:

For whatever reason, my database required my root password.
I used it to check the website but have since deleted it.
You may need to use your own root password to access my website.

All code citations are in the comments.  Stackover flow, lectures, and W3 schools are cited

I tried to make the website as responsive as possible by using % as opposed to px.

All of it is done in PHP and none at all in JS.

The drop down menu is actualyl directly populated from the database so, if another product type is added to the data base, it will automatically appear in the dropdown menu, which I thought was neat.

Connection Errors have been personalized.  More errors would have been put in except that on the user side, very little was required.
For example, if a user had to input an order number they were searching for, then a possible error would be if the number didn't exist.
However, the user wasn't inputing any data - rather, they were selecting from a provided drop down menu.