<?php
/*set up of the footer inspired by the example in lecture 16*/
echo "<footer class='pfooter'>";
echo "<p>Katherine Campbell <br> Copyright &copy   " . date("Y") . "</p>";
echo"</footer>";
?>